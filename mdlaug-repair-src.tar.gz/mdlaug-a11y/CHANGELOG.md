# Changelog

All notable changes to this project are documented here. Format loosely follows
[Keep a Changelog](https://keepachangelog.com/); versioning is pre-1.0 and may shift.

## [0.9.2] - 2026
### Added
- Site-pack plugin system: platform-specific fixes layered on the generic rules,
  matched by host / generator meta / selector signatures. Bundled starters for
  Blacklight/Samvera, DSpace 7, Islandora/Drupal, Omeka S, and IIIF viewers.
- Declarative (JSON) packs anyone can add at runtime from the options page, plus
  an imperative pack form for bundled packs. Authoring guide in docs/SITE-PACKS.md.
- Matched packs surface in the in-page report and in `remediate()` results.

### Fixed
- `undo()` now restores *every* attribute a rule changed on an element (the
  original snapshot previously captured only the first-changed attribute).

## [0.9.1] - 2026
### Fixed
- Extension pages no longer use inline scripts (Manifest V3 CSP blocked them),
  fixing the blank/inert Audit and Settings pages.
- `Store.ping()` added to the Turso store so "Test / create schema" works for
  local-dev and cloud backends.

### Added
- Dashboard: compliance-by-situation bar chart, conformance-level rollup, trend
  over time, and CSV/JSON export (dependency-free SVG).

## [0.9.0] - 2026
### Added
- Local-first assessment storage (IndexedDB) as the zero-setup default, sharing
  one schema with Turso; storage backend selectable (local / Turso dev / cloud).
- Assessment mode: auto-drafts the mDLAUG survey for all 24 situations and saves
  to the chosen store; Turso (libSQL) HTTP client + schema.
- Reading Room: standardized, screen-reader-first view with auto Contents.
- Compute manager: budgeted queue for description/OCR/reflow with pluggable providers.
- Highlight overlay for repairs; bundled pdf.js + mammoth (offline, no fetch step).
- Conformance levels aligned to mDLAUG Appendix IV.

### Notes
- Pre-1.0. Working and tested in Node (jsdom/fake-indexeddb); browser smoke-tested.
