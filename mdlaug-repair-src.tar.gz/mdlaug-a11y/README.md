# mDLAUG Repair

**Make digital libraries usable with a screen reader — repair the page live, read it in a standardized view, and audit it against the mDLAUG guidelines.**

A framework-free, privacy-first browser extension (Manifest V3) that targets the 24 "help-seeking situations" documented by the [Mobile Digital Library Accessibility & Usability Guidelines (mDLAUG)](https://sites.uwm.edu/mdlaug/) from the University of Wisconsin–Milwaukee. Everything runs on-device; nothing is uploaded.

> Status: **v0.9.1**, pre-1.0. Working and tested; APIs may still shift. Issues and PRs welcome.

---

## Why

mDLAUG catalogs 24 concrete ways a blind or low-vision user loses the thread in a mobile digital library — an unlabeled magnifier icon, a PDF that silently downloads, a modal with no way out, a chart with no description. Most are markup defects a script can repair in the live DOM; a few (inaccessible files, images and graphs with no text alternative) need real conversion or a description model. This project does both, and adds two things a fixer alone can't: a **standardized reading view** so a screen-reader user gets the same predictable layout on every library, and an **assessment mode** that drafts the mDLAUG compliance survey automatically and stores the results.

## What it does

- **Repair** — one click rewrites the page's accessibility tree in place: file links get type/size and new-window warnings, icon buttons get names, disclosures get `aria-expanded`, dialogs get focus semantics, pagers become nav landmarks, and so on. Idempotent and fully reversible. A **highlight overlay** boxes every changed element and tags it with its mDLAUG code, because ARIA repairs are invisible by design.
- **Reading Room** — re-presents any page as one consistent, screen-reader-first view (rendered in a shadow root so site CSS can't distort it): skip link → title → auto-generated Contents (jump links from the heading outline) → linear content, with every image, graph, table and attached file handled explicitly. Text-size, spacing, and light/dark/sepia controls included.
- **Conversion studio** — turns a PDF/DOCX/CSV/TXT into accessible, semantic HTML or a properly-styled Word document, entirely in the browser.
- **Compute manager** — heavy jobs (image/graph description, OCR, large-file reflow) run through one budgeted queue with per-capability policy (automatic / on-tap / off), caching, progress and cancel. Providers are pluggable, so a self-hosted vision model can supply descriptions without anything leaving your machine. Machine output is always labelled *unverified*.
- **Assessment → storage** — drafts the mDLAUG survey for all 24 situations (a 1–7 compliance suggestion, auto-detected violations, pre-existing good techniques), lets a human confirm and attach evidence, and saves. Storage **defaults to a local in-browser database with zero setup** and can be pointed at a [Turso](https://turso.tech/) (libSQL) database — local dev or cloud — using the same schema.
- **Dashboard** — compliance by situation, a conformance-level rollup, and a trend over time, with CSV/JSON export. Reads through the same store interface, so it works on local or Turso.
- **Site packs** — platform-specific fixes layered on the generic rules, applied only on matching sites. Bundled starters for Blacklight/Samvera, DSpace 7, Islandora/Drupal, Omeka S, and IIIF viewers; anyone can add their own as declarative JSON at runtime, or contribute a bundled pack. See [`docs/SITE-PACKS.md`](docs/SITE-PACKS.md).

## Install (developer mode)

pdf.js and mammoth are **bundled** — there is nothing to fetch or build.

1. Download or clone this repo.
2. Chrome or Edge → `chrome://extensions` → enable **Developer mode** → **Load unpacked** → select the `extension/` folder.
3. On any page: toolbar icon → **Repair this page**, **Open Reading Room**, **Audit this page**, or **Dashboard**.

`extension/scripts/check-install.sh` confirms the folder is complete; `fetch-vendor.sh` is an optional upgrader, not an install step.

## Try it without installing

Open `demo/demo.html` in any browser. It runs the same engine against a mock digital library built wrong on purpose: repair it, watch the "reader's eye" before/after of what a screen reader announces, toggle the highlight overlay, open the Reading Room, and convert a sample PDF.

## Architecture

One framework-free engine, several surfaces. See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for the module map and the assessment schema.

```
extension/engine/
  remediator.js   in-place DOM repair (idempotent, reversible) + highlight overlay
  converter.js    PDF/DOCX/CSV/TXT -> accessible HTML + dependency-free DOCX writer
  reader.js       the standardized Reading Room (extractor + shadow-DOM renderer)
  compute.js      budgeted job queue for heavy work (description, OCR, reflow)
  assessment.js   audit -> mDLAUG survey scorecard (all 24 situations)
  turso.js        libSQL/Turso HTTP client + schema + data-access layer
  store.js        storage resolver: local IndexedDB (default) or Turso, one interface
extension/ui/     popup, options (studio + settings), assessment editor, dashboard
extension/src/    content script + service worker
extension/packs/  bundled site packs (Blacklight, DSpace, Islandora, Omeka, IIIF)
extension/vendor/ pdf.js (Apache-2.0) + mammoth (BSD-2-Clause), bundled
demo/             standalone, no-install demo
tests/            node-based test suites (see below)
```

## Conformance levels

Every rule's A / AA / AAA level matches **mDLAUG Appendix IV** exactly, and `mDLAUG.remediator.rules()` reports the level per rule so reports can be filtered by conformance target.

## Honest scope

- Repairs cover the highest-severity, universally-fixable situations; site-specific widgets (autocomplete, custom modals) are pattern-matched and may need tuning per platform. Bundled site packs use conservative, well-known selectors and are meant to be tuned against live installs. Every change is recorded on the element (`data-mdlaug` / `data-mdlaug-orig`) and in a per-code report, so nothing is silent.
- Text PDFs reflow cleanly; **scanned/image-only PDFs need OCR**, which isn't bundled (the language data is ~10 MB) — it's an installable provider that degrades to a flag when absent.
- **Image and graph descriptions require a model.** The tool never fabricates them; without a configured description endpoint it flags what's missing, and any generated text is shown as *unverified*.
- Heuristic heading detection can misjudge a borderline sub-head; DOCX→PDF is deliberately left to the browser's print-to-PDF rather than a re-implemented layout engine.

## Testing

```bash
npm install
npm test
```

Suites run in Node with jsdom and fake-indexeddb (no browser needed) and cover the repair engine, converter, compute queue, Reading Room extraction, the Turso client (against a mocked pipeline API), the assessment scorecard, the local store, and the dashboard aggregates. See [`tests/`](tests/).

> Tests validate logic in Node; a few browser-only concerns (e.g. Manifest V3's ban on inline scripts) can't be caught there and are checked by loading the unpacked extension.

## Contributing

See [`CONTRIBUTING.md`](CONTRIBUTING.md). Good first areas: tuning the widget heuristics against a specific platform (DSpace, Islandora, Samvera/Blacklight, Omeka S), adding positive checks to the assessment's "good techniques" detection, and a description-provider adapter for a local model.

## Acknowledgements

- The **mDLAUG guidelines** — Xie et al., University of Wisconsin–Milwaukee — which this tool implements and audits against.
- **pdf.js** (Mozilla, Apache-2.0) and **mammoth.js** (Michael Williamson, BSD-2-Clause), bundled in `extension/vendor/`.

## License

[Apache-2.0](LICENSE). Bundled third-party libraries retain their own licenses; see [`NOTICE`](NOTICE).

This project is not affiliated with or endorsed by the University of Wisconsin–Milwaukee or the mDLAUG authors.
